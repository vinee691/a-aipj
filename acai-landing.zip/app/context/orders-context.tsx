"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import type { CartItem } from "./cart-context"

export type OrderStatus = "pending" | "completed" | "cancelled" | "refunded"

export type Order = {
  id: string
  items: CartItem[]
  total: number
  customerInfo: {
    name: string
    email: string
    phone: string
    address: string
    number: string
    complement?: string
    neighborhood: string
    city: string
    state: string
    zipcode: string
  }
  paymentMethod: string
  status: OrderStatus
  createdAt: string
}

type OrdersContextType = {
  orders: Order[]
  addOrder: (order: Omit<Order, "id" | "createdAt" | "status">) => string
  getOrder: (id: string) => Order | undefined
  updateOrderStatus: (id: string, status: OrderStatus) => void
  refundOrder: (id: string) => void
}

const OrdersContext = createContext<OrdersContextType | undefined>(undefined)

export function OrdersProvider({ children }: { children: ReactNode }) {
  const [orders, setOrders] = useState<Order[]>([])

  // Carregar pedidos do localStorage quando o componente montar
  useEffect(() => {
    const savedOrders = localStorage.getItem("acai-do-bairro-orders")
    if (savedOrders) {
      try {
        setOrders(JSON.parse(savedOrders))
      } catch (error) {
        console.error("Erro ao carregar pedidos:", error)
      }
    }
  }, [])

  // Salvar pedidos no localStorage quando houver mudanças
  useEffect(() => {
    if (orders.length > 0) {
      localStorage.setItem("acai-do-bairro-orders", JSON.stringify(orders))
    }
  }, [orders])

  const addOrder = (orderData: Omit<Order, "id" | "createdAt" | "status">) => {
    const id = `ORD-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).substring(2, 7).toUpperCase()}`

    const newOrder: Order = {
      ...orderData,
      id,
      status: "completed",
      createdAt: new Date().toISOString(),
    }

    setOrders((prevOrders) => [...prevOrders, newOrder])
    return id
  }

  const getOrder = (id: string) => {
    return orders.find((order) => order.id === id)
  }

  const updateOrderStatus = (id: string, status: OrderStatus) => {
    setOrders((prevOrders) => prevOrders.map((order) => (order.id === id ? { ...order, status } : order)))
  }

  const refundOrder = (id: string) => {
    updateOrderStatus(id, "refunded")
  }

  return (
    <OrdersContext.Provider value={{ orders, addOrder, getOrder, updateOrderStatus, refundOrder }}>
      {children}
    </OrdersContext.Provider>
  )
}

export function useOrders() {
  const context = useContext(OrdersContext)
  if (context === undefined) {
    throw new Error("useOrders must be used within an OrdersProvider")
  }
  return context
}
