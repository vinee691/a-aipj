import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { CartProvider } from "./context/cart-context"
import { OrdersProvider } from "./context/orders-context"
import { AuthProvider } from "./context/auth-context"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Açaí do Bairro - O melhor açaí da cidade é só aqui",
  description: "O melhor açaí da cidade é só aqui. Descubra o verdadeiro sabor do açaí com a qualidade Açaí do Bairro.",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="pt-BR">
      <body className={inter.className}>
        <AuthProvider>
          <OrdersProvider>
            <CartProvider>{children}</CartProvider>
          </OrdersProvider>
        </AuthProvider>
      </body>
    </html>
  )
}
