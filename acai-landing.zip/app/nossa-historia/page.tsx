import Image from "next/image"
import Link from "next/link"
import { Award, Heart, Leaf, Users, Facebook, Instagram, Twitter } from "lucide-react"
import CartButton from "../components/cart-button"
import AdminLink from "../components/admin-link"
import ChatBot from "../components/chat-bot"

export default function NossaHistoriaPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 bg-black text-white">
        <div className="container mx-auto flex items-center justify-between px-4 py-3">
          <div className="flex items-center">
            <Link href="/" className="flex items-center">
              <span className="text-2xl font-bold">
                AÇAÍ <span className="italic font-light">do Bairro</span>
              </span>
            </Link>
          </div>
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/" className="text-white hover:text-amber-400 transition-colors">
              Início
            </Link>
            <Link
              href="/nossa-historia"
              className="text-white hover:text-amber-400 transition-colors font-medium text-amber-400"
            >
              Nossa história
            </Link>
            <Link href="/blog" className="text-white hover:text-amber-400 transition-colors">
              Blog
            </Link>
            <Link
              href="/seja-franqueado"
              className="bg-amber-500 hover:bg-amber-600 text-black font-medium px-4 py-2 rounded-md transition-colors"
            >
              Seja um Franqueado
            </Link>
          </nav>
          <div className="ml-auto flex items-center justify-end gap-4">
            <AdminLink />
            <CartButton />
          </div>
          <button className="md:hidden text-white ml-4">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-6 w-6"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
        </div>
      </header>

      {/* Conteúdo da página (mantido o mesmo) */}
      <main className="flex-1">
        {/* ... conteúdo existente ... */}
        <section className="py-12 md:py-16 bg-purple-700 text-white">
          <div className="container mx-auto px-4 text-center">
            <div className="mb-8">
              <h1 className="text-4xl md:text-6xl font-bold mb-6">
                <span className="block">Nossa</span>
                <span className="block text-amber-500">História</span>
              </h1>
              <p className="text-xl max-w-2xl mx-auto text-gray-300">
                Conheça a jornada que nos tornou referência em açaí na cidade
              </p>
            </div>
          </div>
        </section>

        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <div className="relative mb-12 rounded-lg overflow-hidden shadow-xl">
                <div className="aspect-w-16 aspect-h-9 relative h-[400px]">
                  <Image
                    src="/images/fundadores-carlos-ana.png"
                    alt="Carlos e Ana, fundadores do Açaí do Bairro"
                    fill
                    className="object-cover"
                    sizes="(max-width: 768px) 100vw, 800px"
                  />
                </div>
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-6">
                  <p className="text-white text-lg font-medium">
                    Os fundadores Carlos e Ana em 2010, no início da jornada
                  </p>
                </div>
              </div>

              <div className="prose prose-lg max-w-none">
                <h2 className="text-3xl font-bold text-purple-800 mb-6">Do sonho à realidade</h2>

                <p>
                  A história do <strong>Açaí do Bairro</strong> começou em 2010, quando o casal Carlos e Ana Silva,
                  apaixonados pela culinária amazônica, decidiu trazer o verdadeiro sabor do açaí para a cidade. Tudo
                  começou de forma simples, com uma pequena barraca na feira do bairro Jardim Primavera, onde serviam
                  açaí puro, preparado com a receita tradicional que Ana havia aprendido com sua avó, nascida em Belém
                  do Pará.
                </p>

                <p>
                  O que diferenciava o açaí servido por Carlos e Ana era a qualidade da fruta, sempre fresca e
                  selecionada cuidadosamente, e o preparo artesanal que preservava o sabor autêntico da Amazônia. Não
                  demorou muito para que a pequena barraca ganhasse fama no bairro e começasse a atrair clientes de toda
                  a cidade.
                </p>

                <div className="my-12 grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="bg-purple-50 p-6 rounded-lg border border-purple-100 flex flex-col items-center text-center">
                    <div className="bg-purple-100 p-3 rounded-full mb-4">
                      <Leaf className="h-8 w-8 text-purple-700" />
                    </div>
                    <h3 className="text-xl font-bold text-purple-800 mb-2">Compromisso com a qualidade</h3>
                    <p className="text-gray-700">
                      Desde o início, nosso compromisso tem sido oferecer o açaí mais puro e saboroso, respeitando a
                      tradição amazônica e valorizando os produtores locais.
                    </p>
                  </div>

                  <div className="bg-purple-50 p-6 rounded-lg border border-purple-100 flex flex-col items-center text-center">
                    <div className="bg-purple-100 p-3 rounded-full mb-4">
                      <Heart className="h-8 w-8 text-purple-700" />
                    </div>
                    <h3 className="text-xl font-bold text-purple-800 mb-2">Paixão pelo que fazemos</h3>
                    <p className="text-gray-700">
                      A paixão pelo açaí e pelo bem-estar das pessoas é o que nos move todos os dias a oferecer uma
                      experiência única e saudável para nossos clientes.
                    </p>
                  </div>
                </div>

                <h2 className="text-3xl font-bold text-purple-800 mb-6">O crescimento</h2>

                <p>
                  Em 2012, com o sucesso crescente, Carlos e Ana deram um passo importante: abriram a primeira loja
                  física do Açaí do Bairro, ainda no Jardim Primavera. O espaço aconchegante, com decoração inspirada na
                  cultura amazônica, rapidamente se tornou um ponto de encontro para os amantes de açaí.
                </p>

                <p>
                  A dedicação do casal e a qualidade do produto fizeram com que o Açaí do Bairro se destacasse em meio à
                  concorrência. Em 2015, já eram três lojas espalhadas pela cidade, e o cardápio havia se expandido para
                  incluir diversas opções de açaí com complementos, sempre mantendo o compromisso com o sabor autêntico
                  e ingredientes de qualidade.
                </p>

                <div className="my-8 relative rounded-lg overflow-hidden shadow-lg">
                  <div className="aspect-w-16 aspect-h-9 relative h-[300px]">
                    <Image
                      src="/images/primeira-loja-acai.png"
                      alt="Primeira loja do Açaí do Bairro"
                      fill
                      className="object-cover"
                      sizes="(max-width: 768px) 100vw, 800px"
                    />
                  </div>
                  <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-6">
                    <p className="text-white text-lg font-medium">Nossa primeira loja física, inaugurada em 2012</p>
                  </div>
                </div>

                <h2 className="text-3xl font-bold text-purple-800 mb-6">Valores que nos guiam</h2>

                <p>
                  Desde o início, o Açaí do Bairro tem sido guiado por valores sólidos que permeiam todas as nossas
                  ações. Acreditamos na sustentabilidade e no comércio justo, por isso mantemos parcerias diretas com
                  produtores da região amazônica, garantindo que eles recebam um valor justo pelo seu trabalho e que o
                  açaí seja extraído de forma sustentável.
                </p>

                <p>
                  Também valorizamos a transparência com nossos clientes. Todos os nossos produtos têm a composição
                  claramente informada, e fazemos questão de explicar o processo de produção para quem se interessa.
                  Acreditamos que conhecer o que se consome é um direito de todos.
                </p>

                <div className="my-12 grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="bg-purple-50 p-6 rounded-lg border border-purple-100 flex flex-col items-center text-center">
                    <div className="bg-purple-100 p-3 rounded-full mb-4">
                      <Users className="h-8 w-8 text-purple-700" />
                    </div>
                    <h3 className="text-xl font-bold text-purple-800 mb-2">Comunidade</h3>
                    <p className="text-gray-700">
                      Acreditamos no poder de transformação das comunidades. Por isso, parte de nosso lucro é destinado
                      a projetos sociais nas regiões produtoras de açaí.
                    </p>
                  </div>

                  <div className="bg-purple-50 p-6 rounded-lg border border-purple-100 flex flex-col items-center text-center">
                    <div className="bg-purple-100 p-3 rounded-full mb-4">
                      <Award className="h-8 w-8 text-purple-700" />
                    </div>
                    <h3 className="text-xl font-bold text-purple-800 mb-2">Excelência</h3>
                    <p className="text-gray-700">
                      Buscamos a excelência em tudo o que fazemos, desde a seleção dos frutos até o atendimento em
                      nossas lojas, para proporcionar a melhor experiência aos nossos clientes.
                    </p>
                  </div>
                </div>

                <h2 className="text-3xl font-bold text-purple-800 mb-6">Hoje e o futuro</h2>

                <p>
                  Hoje, o Açaí do Bairro conta com 15 lojas próprias e 25 franquias espalhadas por todo o país. Nossa
                  marca se tornou sinônimo de qualidade e autenticidade no mercado de açaí, e temos orgulho de dizer que
                  mantemos o mesmo cuidado e paixão dos primeiros dias.
                </p>

                <p>
                  Carlos e Ana continuam à frente do negócio, agora com uma equipe de mais de 200 colaboradores que
                  compartilham da mesma paixão pelo açaí e pelo atendimento de excelência. Juntos, estamos expandindo a
                  marca para levar o verdadeiro sabor do açaí para cada vez mais pessoas.
                </p>

                <p>
                  Nosso sonho para o futuro é continuar crescendo de forma sustentável, levando o Açaí do Bairro para
                  novas cidades e países, sempre mantendo nossa essência e valores. Queremos ser reconhecidos
                  mundialmente como a marca que revolucionou o consumo de açaí, tornando-o acessível e mantendo sua
                  autenticidade.
                </p>

                <div className="mt-12 bg-purple-100 p-8 rounded-lg border border-purple-200 text-center">
                  <h3 className="text-2xl font-bold text-purple-800 mb-4">Faça parte da nossa história</h3>
                  <p className="text-lg text-purple-900 mb-6">
                    Convidamos você a fazer parte da história do Açaí do Bairro. Visite uma de nossas lojas, experimente
                    nossos produtos e sinta o verdadeiro sabor do açaí amazônico.
                  </p>
                  <Link
                    href="/"
                    className="inline-block bg-amber-500 hover:bg-amber-600 text-black font-medium px-6 py-3 rounded-md transition-colors"
                  >
                    Conheça nossos produtos
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="py-12 bg-purple-700 text-white">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold mb-8">Linha do Tempo</h2>
            <div className="max-w-4xl mx-auto">
              <div className="relative">
                {/* Linha vertical */}
                <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-1 bg-amber-500"></div>

                {/* Marcos */}
                <div className="space-y-12">
                  <div className="relative flex items-center justify-between">
                    <div className="w-5/12 pr-8 text-right">
                      <h3 className="text-xl font-bold text-amber-400">2010</h3>
                      <p className="text-gray-300">
                        Início das atividades com uma barraca na feira do bairro Jardim Primavera
                      </p>
                    </div>
                    <div className="absolute left-1/2 transform -translate-x-1/2 w-8 h-8 rounded-full bg-amber-500 z-10 flex items-center justify-center">
                      <div className="w-4 h-4 rounded-full bg-white"></div>
                    </div>
                    <div className="w-5/12 pl-8"></div>
                  </div>

                  <div className="relative flex items-center justify-between">
                    <div className="w-5/12 pr-8"></div>
                    <div className="absolute left-1/2 transform -translate-x-1/2 w-8 h-8 rounded-full bg-amber-500 z-10 flex items-center justify-center">
                      <div className="w-4 h-4 rounded-full bg-white"></div>
                    </div>
                    <div className="w-5/12 pl-8 text-left">
                      <h3 className="text-xl font-bold text-amber-400">2012</h3>
                      <p className="text-gray-300">Inauguração da primeira loja física no Jardim Primavera</p>
                    </div>
                  </div>

                  <div className="relative flex items-center justify-between">
                    <div className="w-5/12 pr-8 text-right">
                      <h3 className="text-xl font-bold text-amber-400">2015</h3>
                      <p className="text-gray-300">Expansão para três lojas na cidade e ampliação do cardápio</p>
                    </div>
                    <div className="absolute left-1/2 transform -translate-x-1/2 w-8 h-8 rounded-full bg-amber-500 z-10 flex items-center justify-center">
                      <div className="w-4 h-4 rounded-full bg-white"></div>
                    </div>
                    <div className="w-5/12 pl-8"></div>
                  </div>

                  <div className="relative flex items-center justify-between">
                    <div className="w-5/12 pr-8"></div>
                    <div className="absolute left-1/2 transform -translate-x-1/2 w-8 h-8 rounded-full bg-amber-500 z-10 flex items-center justify-center">
                      <div className="w-4 h-4 rounded-full bg-white"></div>
                    </div>
                    <div className="w-5/12 pl-8 text-left">
                      <h3 className="text-xl font-bold text-amber-400">2017</h3>
                      <p className="text-gray-300">Início do programa de franquias e expansão para outros estados</p>
                    </div>
                  </div>

                  <div className="relative flex items-center justify-between">
                    <div className="w-5/12 pr-8 text-right">
                      <h3 className="text-xl font-bold text-amber-400">2020</h3>
                      <p className="text-gray-300">
                        Celebração de 10 anos com 20 lojas em operação e lançamento do e-commerce
                      </p>
                    </div>
                    <div className="absolute left-1/2 transform -translate-x-1/2 w-8 h-8 rounded-full bg-amber-500 z-10 flex items-center justify-center">
                      <div className="w-4 h-4 rounded-full bg-white"></div>
                    </div>
                    <div className="w-5/12 pl-8"></div>
                  </div>

                  <div className="relative flex items-center justify-between">
                    <div className="w-5/12 pr-8"></div>
                    <div className="absolute left-1/2 transform -translate-x-1/2 w-8 h-8 rounded-full bg-amber-500 z-10 flex items-center justify-center">
                      <div className="w-4 h-4 rounded-full bg-white"></div>
                    </div>
                    <div className="w-5/12 pl-8 text-left">
                      <h3 className="text-xl font-bold text-amber-400">Hoje</h3>
                      <p className="text-gray-300">40 lojas em todo o Brasil e planos de expansão internacional</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-purple-800 text-white py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-6 md:mb-0">
              <span className="text-2xl font-bold">
                AÇAÍ <span className="italic font-light">do Bairro</span>
              </span>
              <p className="mt-2 text-gray-400 max-w-md">
                Desde 2010 trazendo o verdadeiro sabor do açaí amazônico para sua mesa, com qualidade, sabor autêntico e
                compromisso com a sustentabilidade.
              </p>
              <p className="mt-2 text-gray-400">
                © {new Date().getFullYear()} Açaí do Bairro. Todos os direitos reservados.
              </p>
              <p className="mt-1 text-gray-400 text-sm">CNPJ: 12.345.678/0001-90</p>
            </div>
            <div className="flex space-x-4">
              <Link href="https://facebook.com" className="text-white hover:text-amber-400 transition-colors">
                <Facebook className="h-6 w-6" />
              </Link>
              <Link href="https://tiktok.com" className="text-white hover:text-amber-400 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z" />
                </svg>
              </Link>
              <Link href="https://instagram.com" className="text-white hover:text-amber-400 transition-colors">
                <Instagram className="h-6 w-6" />
              </Link>
              <Link href="https://twitter.com" className="text-white hover:text-amber-400 transition-colors">
                <Twitter className="h-6 w-6" />
              </Link>
            </div>
          </div>
        </div>
      </footer>

      {/* Componente de Chat com IA */}
      <ChatBot />
    </div>
  )
}
