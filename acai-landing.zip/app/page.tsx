import Image from "next/image"
import Link from "next/link"
import { Facebook, Instagram, Twitter } from "lucide-react"
import CartButton from "./components/cart-button"
import ProductCard from "./components/product-card"
import CustomAcai from "./components/custom-acai"
import AdminLink from "./components/admin-link"
import ChatBot from "./components/chat-bot"

export default function Home() {
  const products = [
    {
      id: "acai-tradicional",
      name: "Açaí Tradicional",
      price: 18.9,
      description:
        "Açaí puro e cremoso, preparado com a fruta fresca da Amazônia. Rico em nutrientes e com sabor autêntico.",
      image: "/images/acai-tradicional.png",
    },
    {
      id: "acai-frutas",
      name: "Açaí com Frutas",
      price: 22.9,
      description:
        "Açaí cremoso acompanhado de banana, morango e granola. Uma combinação perfeita de sabores e nutrientes.",
      image: "/images/acai-frutas.png",
    },
    {
      id: "acai-proteico",
      name: "Açaí Proteico",
      price: 25.9,
      description:
        "Açaí turbinado com whey protein, amendoim e banana. Ideal para pré ou pós-treino, com alto valor nutricional.",
      image: "/images/acai-proteico.png",
    },
    {
      id: "acai-granola",
      name: "Açaí com Granola",
      price: 20.9,
      description: "Açaí cremoso com camadas de granola crocante. Uma combinação clássica e deliciosa.",
      image: "/images/acai-granola.png",
    },
    {
      id: "acai-gourmet",
      name: "Açaí Gourmet",
      price: 28.9,
      description:
        "Açaí premium com leite condensado, morango, banana, granola, calda de chocolate e chantilly. Uma explosão de sabores.",
      image: "/images/acai-gourmet.png",
    },
    {
      id: "acai-zero",
      name: "Açaí Zero",
      price: 23.9,
      description:
        "Açaí sem adição de açúcar com chia, frutas frescas e granola light. Ideal para quem busca uma alimentação mais saudável.",
      image: "/images/acai-zero.png",
    },
  ]

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 bg-black text-white">
        <div className="container mx-auto flex items-center justify-between px-4 py-3">
          <div className="flex items-center">
            <Link href="/" className="flex items-center">
              <span className="text-2xl font-bold">
                AÇAÍ <span className="italic font-light">do Bairro</span>
              </span>
            </Link>
          </div>
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/" className="text-white hover:text-amber-400 transition-colors">
              Início
            </Link>
            <Link href="/nossa-historia" className="text-white hover:text-amber-400 transition-colors">
              Nossa história
            </Link>
            <Link href="/blog" className="text-white hover:text-amber-400 transition-colors">
              Blog
            </Link>
            <Link
              href="/seja-franqueado"
              className="bg-amber-500 hover:bg-amber-600 text-black font-medium px-4 py-2 rounded-md transition-colors"
            >
              Seja um Franqueado
            </Link>
          </nav>
          <div className="ml-auto flex items-center justify-end gap-4">
            <AdminLink />
            <CartButton />
          </div>
          <button className="md:hidden text-white ml-4">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-6 w-6"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
        </div>
      </header>

      <main className="flex-1">
        <section className="py-12 md:py-16 bg-purple-700 text-white">
          <div className="container mx-auto px-4 text-center">
            <div className="mb-8">
              <h1 className="text-4xl md:text-6xl font-bold mb-6">
                <span className="block">Descubra o melhor açaí</span>
                <span className="block text-amber-500">do seu bairro!</span>
              </h1>
              <p className="text-xl max-w-2xl mx-auto text-gray-300">O melhor açaí da cidade é só aqui</p>
            </div>
          </div>
        </section>

        <section className="py-12 bg-white">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
              Nossos <span className="text-amber-500">Produtos</span>
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {products.map((product) => (
                <ProductCard
                  key={product.id}
                  id={product.id}
                  name={product.name}
                  price={product.price}
                  description={product.description}
                  image={product.image}
                />
              ))}
            </div>
          </div>
        </section>

        <section className="py-12 bg-gray-100">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-8">
              Monte seu <span className="text-amber-500">Próprio Açaí</span>
            </h2>
            <p className="text-lg max-w-3xl mx-auto mb-8">
              Escolha a base de açaí e adicione seus complementos favoritos para criar uma experiência única.
            </p>
            <CustomAcai />
          </div>
        </section>

        <section className="py-12 bg-purple-700 text-white">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-8">
              Faça seu <span className="text-amber-500">Pedido</span>
            </h2>
            <div className="flex flex-col md:flex-row items-center justify-center gap-6 mb-8">
              <Link href="https://play.google.com/store" className="transform hover:scale-105 transition-transform">
                <Image
                  src="/placeholder.svg?height=60&width=200"
                  alt="Disponível no Google Play"
                  width={200}
                  height={60}
                  className="h-auto"
                />
              </Link>
              <Link href="https://apps.apple.com" className="transform hover:scale-105 transition-transform">
                <Image
                  src="/placeholder.svg?height=60&width=200"
                  alt="Baixar na App Store"
                  width={200}
                  height={60}
                  className="h-auto"
                />
              </Link>
            </div>
            <p className="text-lg max-w-2xl mx-auto">
              Baixe nosso aplicativo e peça seu açaí favorito com apenas alguns cliques. Entrega rápida e segura!
            </p>
          </div>
        </section>
      </main>

      <footer className="bg-purple-800 text-white py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-6 md:mb-0">
              <span className="text-2xl font-bold">
                AÇAÍ <span className="italic font-light">do Bairro</span>
              </span>
              <p className="mt-2 text-gray-400 max-w-md">
                Desde 2010 trazendo o verdadeiro sabor do açaí amazônico para sua mesa, com qualidade, sabor autêntico e
                compromisso com a sustentabilidade.
              </p>
              <p className="mt-2 text-gray-400">
                © {new Date().getFullYear()} Açaí do Bairro. Todos os direitos reservados.
              </p>
              <p className="mt-1 text-gray-400 text-sm">CNPJ: 12.345.678/0001-90</p>
            </div>
            <div className="flex space-x-4">
              <Link href="https://facebook.com" className="text-white hover:text-amber-400 transition-colors">
                <Facebook className="h-6 w-6" />
              </Link>
              <Link href="https://tiktok.com" className="text-white hover:text-amber-400 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z" />
                </svg>
              </Link>
              <Link href="https://instagram.com" className="text-white hover:text-amber-400 transition-colors">
                <Instagram className="h-6 w-6" />
              </Link>
              <Link href="https://twitter.com" className="text-white hover:text-amber-400 transition-colors">
                <Twitter className="h-6 w-6" />
              </Link>
            </div>
          </div>
        </div>
      </footer>

      {/* Componente de Chat com IA */}
      <ChatBot />
    </div>
  )
}
