"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { ArrowLeft, CreditCard, MapPin, Truck } from "lucide-react"
import { useCart } from "../context/cart-context"
import { useOrders } from "../context/orders-context"
import ChatBot from "../components/chat-bot"

export default function CheckoutPage() {
  const router = useRouter()
  const { items, total, clearCart } = useCart()
  const { addOrder } = useOrders()
  const [step, setStep] = useState(1)
  const [loading, setLoading] = useState(false)
  const [orderComplete, setOrderComplete] = useState(false)
  const [orderNumber, setOrderNumber] = useState("")

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
    number: "",
    complement: "",
    neighborhood: "",
    city: "",
    state: "",
    zipcode: "",
    paymentMethod: "credit",
    cardNumber: "",
    cardName: "",
    cardExpiry: "",
    cardCvv: "",
  })

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const nextStep = () => {
    window.scrollTo(0, 0)
    setStep(step + 1)
  }

  const prevStep = () => {
    setStep(step - 1)
  }

  const formatPrice = (price: number) => {
    return price.toFixed(2).replace(".", ",")
  }

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    // Criar o pedido no sistema
    const orderId = addOrder({
      items: [...items],
      total: total + 5, // Total + taxa de entrega
      customerInfo: {
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        address: formData.address,
        number: formData.number,
        complement: formData.complement,
        neighborhood: formData.neighborhood,
        city: formData.city,
        state: formData.state,
        zipcode: formData.zipcode,
      },
      paymentMethod: formData.paymentMethod,
    })

    // Simular processamento
    setTimeout(() => {
      setOrderNumber(orderId)
      setOrderComplete(true)
      clearCart()
      setLoading(false)
    }, 2000)
  }

  if (orderComplete) {
    return (
      <div className="min-h-screen bg-gray-50 py-12">
        <div className="container mx-auto px-4 max-w-3xl">
          <div className="bg-white rounded-lg shadow-lg p-8 text-center">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-10 w-10 text-green-500"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-4">Pedido Realizado com Sucesso!</h1>
            <p className="text-gray-600 mb-6">
              Seu pedido #{orderNumber} foi confirmado e está sendo preparado. Você receberá atualizações por e-mail.
            </p>
            <div className="bg-gray-50 p-4 rounded-lg mb-6">
              <p className="text-gray-700">
                Tempo estimado de entrega: <span className="font-bold">30-45 minutos</span>
              </p>
            </div>
            <Link
              href="/"
              className="inline-block bg-amber-500 hover:bg-amber-600 text-black font-medium px-6 py-3 rounded-md transition-colors"
            >
              Voltar para a Loja
            </Link>
          </div>
        </div>
        <ChatBot />
      </div>
    )
  }

  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50 py-12">
        <div className="container mx-auto px-4 max-w-3xl">
          <div className="bg-white rounded-lg shadow-lg p-8 text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Seu carrinho está vazio</h1>
            <p className="text-gray-600 mb-6">Adicione alguns produtos antes de finalizar a compra.</p>
            <Link
              href="/"
              className="inline-block bg-amber-500 hover:bg-amber-600 text-black font-medium px-6 py-3 rounded-md transition-colors"
            >
              Voltar para a Loja
            </Link>
          </div>
        </div>
        <ChatBot />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="container mx-auto px-4">
        <div className="flex items-center mb-8">
          <Link href="/" className="text-gray-600 hover:text-gray-900 flex items-center">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Voltar para a loja
          </Link>
        </div>

        <div className="flex flex-col lg:flex-row gap-8">
          <div className="lg:w-2/3">
            <div className="bg-white rounded-lg shadow-lg overflow-hidden mb-6">
              <div className="p-6 border-b">
                <h1 className="text-2xl font-bold">Finalizar Compra</h1>
              </div>

              <div className="p-6">
                <div className="flex mb-6">
                  <div className="flex items-center">
                    <div
                      className={`w-10 h-10 rounded-full flex items-center justify-center ${
                        step >= 1 ? "bg-amber-500 text-black" : "bg-gray-200 text-gray-600"
                      } mr-2`}
                    >
                      1
                    </div>
                    <span className={step >= 1 ? "font-medium" : "text-gray-500"}>Entrega</span>
                  </div>
                  <div className={`flex-1 h-0.5 mx-4 my-auto ${step >= 2 ? "bg-amber-500" : "bg-gray-200"}`}></div>
                  <div className="flex items-center">
                    <div
                      className={`w-10 h-10 rounded-full flex items-center justify-center ${
                        step >= 2 ? "bg-amber-500 text-black" : "bg-gray-200 text-gray-600"
                      } mr-2`}
                    >
                      2
                    </div>
                    <span className={step >= 2 ? "font-medium" : "text-gray-500"}>Pagamento</span>
                  </div>
                  <div className={`flex-1 h-0.5 mx-4 my-auto ${step >= 3 ? "bg-amber-500" : "bg-gray-200"}`}></div>
                  <div className="flex items-center">
                    <div
                      className={`w-10 h-10 rounded-full flex items-center justify-center ${
                        step >= 3 ? "bg-amber-500 text-black" : "bg-gray-200 text-gray-600"
                      } mr-2`}
                    >
                      3
                    </div>
                    <span className={step >= 3 ? "font-medium" : "text-gray-500"}>Confirmação</span>
                  </div>
                </div>

                {step === 1 && (
                  <form>
                    <div className="flex items-center gap-2 mb-6">
                      <MapPin className="h-5 w-5 text-amber-500" />
                      <h2 className="text-xl font-medium">Informações de Entrega</h2>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                      <div className="col-span-2">
                        <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                          Nome completo
                        </label>
                        <input
                          type="text"
                          id="name"
                          name="name"
                          value={formData.name}
                          onChange={handleInputChange}
                          className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-amber-500"
                          required
                        />
                      </div>

                      <div>
                        <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                          E-mail
                        </label>
                        <input
                          type="email"
                          id="email"
                          name="email"
                          value={formData.email}
                          onChange={handleInputChange}
                          className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-amber-500"
                          required
                        />
                      </div>

                      <div>
                        <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                          Telefone
                        </label>
                        <input
                          type="tel"
                          id="phone"
                          name="phone"
                          value={formData.phone}
                          onChange={handleInputChange}
                          className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-amber-500"
                          required
                        />
                      </div>

                      <div>
                        <label htmlFor="zipcode" className="block text-sm font-medium text-gray-700 mb-1">
                          CEP
                        </label>
                        <input
                          type="text"
                          id="zipcode"
                          name="zipcode"
                          value={formData.zipcode}
                          onChange={handleInputChange}
                          className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-amber-500"
                          required
                        />
                      </div>

                      <div>
                        <label htmlFor="address" className="block text-sm font-medium text-gray-700 mb-1">
                          Endereço
                        </label>
                        <input
                          type="text"
                          id="address"
                          name="address"
                          value={formData.address}
                          onChange={handleInputChange}
                          className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-amber-500"
                          required
                        />
                      </div>

                      <div>
                        <label htmlFor="number" className="block text-sm font-medium text-gray-700 mb-1">
                          Número
                        </label>
                        <input
                          type="text"
                          id="number"
                          name="number"
                          value={formData.number}
                          onChange={handleInputChange}
                          className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-amber-500"
                          required
                        />
                      </div>

                      <div>
                        <label htmlFor="complement" className="block text-sm font-medium text-gray-700 mb-1">
                          Complemento (opcional)
                        </label>
                        <input
                          type="text"
                          id="complement"
                          name="complement"
                          value={formData.complement}
                          onChange={handleInputChange}
                          className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-amber-500"
                        />
                      </div>

                      <div>
                        <label htmlFor="neighborhood" className="block text-sm font-medium text-gray-700 mb-1">
                          Bairro
                        </label>
                        <input
                          type="text"
                          id="neighborhood"
                          name="neighborhood"
                          value={formData.neighborhood}
                          onChange={handleInputChange}
                          className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-amber-500"
                          required
                        />
                      </div>

                      <div>
                        <label htmlFor="city" className="block text-sm font-medium text-gray-700 mb-1">
                          Cidade
                        </label>
                        <input
                          type="text"
                          id="city"
                          name="city"
                          value={formData.city}
                          onChange={handleInputChange}
                          className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-amber-500"
                          required
                        />
                      </div>

                      <div>
                        <label htmlFor="state" className="block text-sm font-medium text-gray-700 mb-1">
                          Estado
                        </label>
                        <select
                          id="state"
                          name="state"
                          value={formData.state}
                          onChange={handleSelectChange}
                          className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-amber-500"
                          required
                        >
                          <option value="">Selecione</option>
                          <option value="AC">Acre</option>
                          <option value="AL">Alagoas</option>
                          <option value="AP">Amapá</option>
                          <option value="AM">Amazonas</option>
                          <option value="BA">Bahia</option>
                          <option value="CE">Ceará</option>
                          <option value="DF">Distrito Federal</option>
                          <option value="ES">Espírito Santo</option>
                          <option value="GO">Goiás</option>
                          <option value="MA">Maranhão</option>
                          <option value="MT">Mato Grosso</option>
                          <option value="MS">Mato Grosso do Sul</option>
                          <option value="MG">Minas Gerais</option>
                          <option value="PA">Pará</option>
                          <option value="PB">Paraíba</option>
                          <option value="PR">Paraná</option>
                          <option value="PE">Pernambuco</option>
                          <option value="PI">Piauí</option>
                          <option value="RJ">Rio de Janeiro</option>
                          <option value="RN">Rio Grande do Norte</option>
                          <option value="RS">Rio Grande do Sul</option>
                          <option value="RO">Rondônia</option>
                          <option value="RR">Roraima</option>
                          <option value="SC">Santa Catarina</option>
                          <option value="SP">São Paulo</option>
                          <option value="SE">Sergipe</option>
                          <option value="TO">Tocantins</option>
                        </select>
                      </div>
                    </div>

                    <div className="flex justify-end">
                      <button
                        type="button"
                        onClick={nextStep}
                        className="bg-amber-500 hover:bg-amber-600 text-black font-medium px-6 py-3 rounded-md transition-colors"
                      >
                        Continuar para Pagamento
                      </button>
                    </div>
                  </form>
                )}

                {step === 2 && (
                  <form>
                    <div className="flex items-center gap-2 mb-6">
                      <CreditCard className="h-5 w-5 text-amber-500" />
                      <h2 className="text-xl font-medium">Informações de Pagamento</h2>
                    </div>

                    <div className="mb-6">
                      <div className="flex flex-col gap-3">
                        <label className="flex items-center p-4 border rounded-md cursor-pointer hover:bg-gray-50">
                          <input
                            type="radio"
                            name="paymentMethod"
                            value="credit"
                            checked={formData.paymentMethod === "credit"}
                            onChange={handleInputChange}
                            className="mr-3"
                          />
                          <div>
                            <div className="font-medium">Cartão de Crédito</div>
                            <div className="text-sm text-gray-500">Visa, Mastercard, Elo, American Express</div>
                          </div>
                        </label>

                        <label className="flex items-center p-4 border rounded-md cursor-pointer hover:bg-gray-50">
                          <input
                            type="radio"
                            name="paymentMethod"
                            value="debit"
                            checked={formData.paymentMethod === "debit"}
                            onChange={handleInputChange}
                            className="mr-3"
                          />
                          <div>
                            <div className="font-medium">Cartão de Débito</div>
                            <div className="text-sm text-gray-500">Visa, Mastercard, Elo</div>
                          </div>
                        </label>

                        <label className="flex items-center p-4 border rounded-md cursor-pointer hover:bg-gray-50">
                          <input
                            type="radio"
                            name="paymentMethod"
                            value="pix"
                            checked={formData.paymentMethod === "pix"}
                            onChange={handleInputChange}
                            className="mr-3"
                          />
                          <div>
                            <div className="font-medium">PIX</div>
                            <div className="text-sm text-gray-500">Pagamento instantâneo</div>
                          </div>
                        </label>

                        <label className="flex items-center p-4 border rounded-md cursor-pointer hover:bg-gray-50">
                          <input
                            type="radio"
                            name="paymentMethod"
                            value="cash"
                            checked={formData.paymentMethod === "cash"}
                            onChange={handleInputChange}
                            className="mr-3"
                          />
                          <div>
                            <div className="font-medium">Dinheiro na Entrega</div>
                            <div className="text-sm text-gray-500">Pagamento em espécie ao receber</div>
                          </div>
                        </label>
                      </div>
                    </div>

                    {(formData.paymentMethod === "credit" || formData.paymentMethod === "debit") && (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                        <div className="col-span-2">
                          <label htmlFor="cardNumber" className="block text-sm font-medium text-gray-700 mb-1">
                            Número do Cartão
                          </label>
                          <input
                            type="text"
                            id="cardNumber"
                            name="cardNumber"
                            value={formData.cardNumber}
                            onChange={handleInputChange}
                            placeholder="0000 0000 0000 0000"
                            className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-amber-500"
                            required
                          />
                        </div>

                        <div className="col-span-2">
                          <label htmlFor="cardName" className="block text-sm font-medium text-gray-700 mb-1">
                            Nome no Cartão
                          </label>
                          <input
                            type="text"
                            id="cardName"
                            name="cardName"
                            value={formData.cardName}
                            onChange={handleInputChange}
                            className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-amber-500"
                            required
                          />
                        </div>

                        <div>
                          <label htmlFor="cardExpiry" className="block text-sm font-medium text-gray-700 mb-1">
                            Data de Validade
                          </label>
                          <input
                            type="text"
                            id="cardExpiry"
                            name="cardExpiry"
                            value={formData.cardExpiry}
                            onChange={handleInputChange}
                            placeholder="MM/AA"
                            className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-amber-500"
                            required
                          />
                        </div>

                        <div>
                          <label htmlFor="cardCvv" className="block text-sm font-medium text-gray-700 mb-1">
                            Código de Segurança (CVV)
                          </label>
                          <input
                            type="text"
                            id="cardCvv"
                            name="cardCvv"
                            value={formData.cardCvv}
                            onChange={handleInputChange}
                            placeholder="123"
                            className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-amber-500"
                            required
                          />
                        </div>
                      </div>
                    )}

                    <div className="flex justify-between">
                      <button
                        type="button"
                        onClick={prevStep}
                        className="border border-gray-300 hover:bg-gray-50 text-gray-700 font-medium px-6 py-3 rounded-md transition-colors"
                      >
                        Voltar
                      </button>
                      <button
                        type="button"
                        onClick={nextStep}
                        className="bg-amber-500 hover:bg-amber-600 text-black font-medium px-6 py-3 rounded-md transition-colors"
                      >
                        Revisar Pedido
                      </button>
                    </div>
                  </form>
                )}

                {step === 3 && (
                  <form onSubmit={handleSubmitOrder}>
                    <div className="flex items-center gap-2 mb-6">
                      <Truck className="h-5 w-5 text-amber-500" />
                      <h2 className="text-xl font-medium">Revisar Pedido</h2>
                    </div>

                    <div className="mb-8">
                      <h3 className="font-medium text-gray-700 mb-3">Itens do Pedido</h3>
                      <div className="border rounded-md overflow-hidden">
                        {items.map((item, index) => (
                          <div
                            key={`${item.id}-${item.size}-${index}`}
                            className="flex items-center p-4 border-b last:border-b-0"
                          >
                            <div className="w-12 h-12 bg-gray-100 rounded-md overflow-hidden flex-shrink-0 mr-4">
                              <img
                                src={item.image || "/placeholder.svg"}
                                alt={item.name}
                                className="w-full h-full object-cover"
                              />
                            </div>
                            <div className="flex-1">
                              <h4 className="font-medium">{item.name}</h4>
                              <p className="text-sm text-gray-500">Tamanho: {item.size}</p>
                            </div>
                            <div className="text-right">
                              <div className="font-medium">
                                {item.quantity} x R$ {formatPrice(item.price)}
                              </div>
                              <div className="text-sm text-gray-500">R$ {formatPrice(item.price * item.quantity)}</div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                      <div>
                        <h3 className="font-medium text-gray-700 mb-3">Endereço de Entrega</h3>
                        <div className="bg-gray-50 p-4 rounded-md">
                          <p className="font-medium">{formData.name}</p>
                          <p>
                            {formData.address}, {formData.number}
                            {formData.complement ? ` - ${formData.complement}` : ""}
                          </p>
                          <p>
                            {formData.neighborhood}, {formData.city} - {formData.state}
                          </p>
                          <p>CEP: {formData.zipcode}</p>
                          <p>Telefone: {formData.phone}</p>
                        </div>
                      </div>

                      <div>
                        <h3 className="font-medium text-gray-700 mb-3">Método de Pagamento</h3>
                        <div className="bg-gray-50 p-4 rounded-md">
                          {formData.paymentMethod === "credit" && (
                            <>
                              <p className="font-medium">Cartão de Crédito</p>
                              <p>**** **** **** {formData.cardNumber.slice(-4) || "****"}</p>
                              <p>{formData.cardName || "Nome no Cartão"}</p>
                            </>
                          )}
                          {formData.paymentMethod === "debit" && (
                            <>
                              <p className="font-medium">Cartão de Débito</p>
                              <p>**** **** **** {formData.cardNumber.slice(-4) || "****"}</p>
                              <p>{formData.cardName || "Nome no Cartão"}</p>
                            </>
                          )}
                          {formData.paymentMethod === "pix" && <p className="font-medium">Pagamento via PIX</p>}
                          {formData.paymentMethod === "cash" && (
                            <p className="font-medium">Pagamento em Dinheiro na Entrega</p>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex justify-between">
                      <button
                        type="button"
                        onClick={prevStep}
                        className="border border-gray-300 hover:bg-gray-50 text-gray-700 font-medium px-6 py-3 rounded-md transition-colors"
                      >
                        Voltar
                      </button>
                      <button
                        type="submit"
                        disabled={loading}
                        className="bg-amber-500 hover:bg-amber-600 text-black font-medium px-6 py-3 rounded-md transition-colors flex items-center"
                      >
                        {loading ? (
                          <>
                            <svg
                              className="animate-spin -ml-1 mr-2 h-4 w-4 text-black"
                              xmlns="http://www.w3.org/2000/svg"
                              fill="none"
                              viewBox="0 0 24 24"
                            >
                              <circle
                                className="opacity-25"
                                cx="12"
                                cy="12"
                                r="10"
                                stroke="currentColor"
                                strokeWidth="4"
                              ></circle>
                              <path
                                className="opacity-75"
                                fill="currentColor"
                                d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                              ></path>
                            </svg>
                            Processando...
                          </>
                        ) : (
                          "Finalizar Pedido"
                        )}
                      </button>
                    </div>
                  </form>
                )}
              </div>
            </div>
          </div>

          <div className="lg:w-1/3">
            <div className="bg-white rounded-lg shadow-lg overflow-hidden sticky top-6">
              <div className="p-6 border-b">
                <h2 className="text-xl font-bold">Resumo do Pedido</h2>
              </div>
              <div className="p-6">
                <div className="space-y-4 mb-6">
                  {items.map((item, index) => (
                    <div key={`${item.id}-${item.size}-${index}`} className="flex justify-between">
                      <div>
                        <span className="font-medium">
                          {item.quantity}x {item.name}
                        </span>
                        <p className="text-sm text-gray-500">{item.size}</p>
                      </div>
                      <span>R$ {formatPrice(item.price * item.quantity)}</span>
                    </div>
                  ))}
                </div>

                <div className="border-t pt-4 space-y-2">
                  <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span>R$ {formatPrice(total)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Taxa de entrega</span>
                    <span>R$ 5,00</span>
                  </div>
                  <div className="flex justify-between font-bold text-lg border-t border-dashed pt-4 mt-4">
                    <span>Total</span>
                    <span>R$ {formatPrice(total + 5)}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <ChatBot />
    </div>
  )
}
