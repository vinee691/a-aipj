"use client"

import Link from "next/link"
import { ShieldCheck } from "lucide-react"

export default function AdminLink() {
  return (
    <Link
      href="/admin/login"
      className="text-white hover:text-amber-400 transition-colors flex items-center"
      title="Área Administrativa"
    >
      <ShieldCheck className="h-6 w-6" />
    </Link>
  )
}
