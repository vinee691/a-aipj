"use client"

import { useState } from "react"
import { useCart } from "../context/cart-context"

type Complement = {
  id: string
  name: string
  price: number
  selected: boolean
}

type Size = {
  id: string
  name: string
  ml: string
  price: number
}

export default function CustomAcai() {
  const { addItem } = useCart()
  const [selectedSize, setSelectedSize] = useState("pequeno")

  const sizes: Size[] = [
    { id: "pequeno", name: "Pequeno", ml: "300ml", price: 15.9 },
    { id: "medio", name: "Médio", ml: "500ml", price: 19.9 },
    { id: "grande", name: "Grande", ml: "700ml", price: 24.9 },
  ]

  const [complements, setComplements] = useState<Complement[]>([
    { id: "granola", name: "Granola", price: 2, selected: false },
    { id: "banana", name: "Banana", price: 2, selected: false },
    { id: "morango", name: "Morango", price: 3, selected: false },
    { id: "leite-condensado", name: "Leite condensado", price: 2.5, selected: false },
  ])

  const [toppings, setToppings] = useState<Complement[]>([
    { id: "mel", name: "Mel", price: 1.5, selected: false },
    { id: "pacoca", name: "Paçoca", price: 2, selected: false },
    { id: "chocolate", name: "Chocolate", price: 2.5, selected: false },
    { id: "castanhas", name: "Castanhas", price: 3, selected: false },
    { id: "coco", name: "Coco ralado", price: 1.5, selected: false },
    { id: "whey", name: "Whey protein", price: 4, selected: false },
  ])

  const toggleComplement = (id: string) => {
    setComplements(complements.map((item) => (item.id === id ? { ...item, selected: !item.selected } : item)))
  }

  const toggleTopping = (id: string) => {
    setToppings(toppings.map((item) => (item.id === id ? { ...item, selected: !item.selected } : item)))
  }

  const getCurrentSize = () => {
    return sizes.find((size) => size.id === selectedSize) || sizes[0]
  }

  const calculateTotal = () => {
    const sizePrice = getCurrentSize().price
    const complementsPrice = complements.filter((item) => item.selected).reduce((sum, item) => sum + item.price, 0)
    const toppingsPrice = toppings.filter((item) => item.selected).reduce((sum, item) => sum + item.price, 0)

    return sizePrice + complementsPrice + toppingsPrice
  }

  const formatPrice = (price: number) => {
    return price.toFixed(2).replace(".", ",")
  }

  const getSelectedItems = () => {
    const selectedComplements = complements.filter((item) => item.selected).map((item) => item.name)

    const selectedToppings = toppings.filter((item) => item.selected).map((item) => item.name)

    return [...selectedComplements, ...selectedToppings]
  }

  const handleAddToCart = () => {
    const size = getCurrentSize()
    const selectedItems = getSelectedItems()
    const description = selectedItems.length > 0 ? `Com ${selectedItems.join(", ")}` : "Sem complementos"

    addItem({
      id: "custom-acai",
      name: `Açaí Personalizado (${size.ml})`,
      price: calculateTotal(),
      size: size.ml,
      image: "/placeholder.svg?height=300&width=400",
    })
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg max-w-3xl mx-auto">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div>
          <h3 className="font-bold text-lg mb-4">1. Escolha o tamanho</h3>
          <div className="flex flex-col gap-2">
            {sizes.map((size) => (
              <label
                key={size.id}
                className={`flex items-center p-3 border rounded cursor-pointer hover:bg-gray-50 ${
                  selectedSize === size.id ? "bg-amber-100 border-amber-500" : ""
                }`}
              >
                <input
                  type="radio"
                  name="size"
                  className="mr-2"
                  checked={selectedSize === size.id}
                  onChange={() => setSelectedSize(size.id)}
                />
                <span>
                  {size.name} ({size.ml}) - R$ {formatPrice(size.price)}
                </span>
              </label>
            ))}
          </div>
        </div>

        <div>
          <h3 className="font-bold text-lg mb-4">2. Escolha os complementos</h3>
          <div className="flex flex-col gap-2">
            {complements.map((item) => (
              <label
                key={item.id}
                className={`flex items-center p-3 border rounded cursor-pointer hover:bg-gray-50 ${
                  item.selected ? "bg-amber-100 border-amber-500" : ""
                }`}
              >
                <input
                  type="checkbox"
                  className="mr-2"
                  checked={item.selected}
                  onChange={() => toggleComplement(item.id)}
                />
                <span>
                  {item.name} - R$ {formatPrice(item.price)}
                </span>
              </label>
            ))}
          </div>
        </div>
      </div>

      <div className="mt-6">
        <h3 className="font-bold text-lg mb-4">3. Adicione coberturas</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2 mb-6">
          {toppings.map((item) => (
            <label
              key={item.id}
              className={`flex items-center p-3 border rounded cursor-pointer hover:bg-gray-50 ${
                item.selected ? "bg-amber-100 border-amber-500" : ""
              }`}
            >
              <input type="checkbox" className="mr-2" checked={item.selected} onChange={() => toggleTopping(item.id)} />
              <span>
                {item.name} - R$ {formatPrice(item.price)}
              </span>
            </label>
          ))}
        </div>
      </div>

      <div className="flex justify-between items-center border-t pt-4">
        <div className="text-xl font-bold">
          Total: <span className="text-amber-500">R$ {formatPrice(calculateTotal())}</span>
        </div>
        <button
          className="bg-amber-500 hover:bg-amber-600 text-black font-medium px-6 py-2 rounded-md transition-colors"
          onClick={handleAddToCart}
        >
          Adicionar ao Carrinho
        </button>
      </div>
    </div>
  )
}
