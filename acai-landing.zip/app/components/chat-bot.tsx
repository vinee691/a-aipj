"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { MessageSquare, Send, X, ChevronDown, ChevronUp } from "lucide-react"
import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

type Message = {
  id: string
  content: string
  role: "user" | "assistant"
  timestamp: Date
}

export default function ChatBot() {
  const [isOpen, setIsOpen] = useState(false)
  const [isMinimized, setIsMinimized] = useState(false)
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  // Atualizar a mensagem de boas-vindas para ser mais amigável e informativa

  // Adicionar mensagem de boas-vindas quando o chat for aberto pela primeira vez
  useEffect(() => {
    if (isOpen && messages.length === 0) {
      setMessages([
        {
          id: "welcome",
          content:
            "Olá! 👋 Sou o assistente virtual do Açaí do Bairro. Posso ajudar com informações sobre nossos produtos, acompanhar seu pedido ou tirar dúvidas sobre entregas. Como posso te ajudar hoje?",
          role: "assistant",
          timestamp: new Date(),
        },
      ])
    }
  }, [isOpen, messages.length])

  // Rolar para a última mensagem quando uma nova mensagem for adicionada
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" })
    }
  }, [messages])

  // Focar no input quando o chat for aberto
  useEffect(() => {
    if (isOpen && !isMinimized && inputRef.current) {
      inputRef.current.focus()
    }
  }, [isOpen, isMinimized])

  const toggleChat = () => {
    setIsOpen(!isOpen)
    setIsMinimized(false)
  }

  const toggleMinimize = () => {
    setIsMinimized(!isMinimized)
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInput(e.target.value)
  }

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && input.trim()) {
      handleSendMessage()
    }
  }

  // Modificar a função getPreDefinedResponse para melhorar a detecção de perguntas sobre tempo de entrega
  // e tornar as respostas mais naturais

  const getPreDefinedResponse = (userMessage: string): string | null => {
    const lowerCaseMessage = userMessage.toLowerCase()

    // Respostas sobre tempo de entrega e status do pedido
    if (
      lowerCaseMessage.includes("tempo") ||
      lowerCaseMessage.includes("demora") ||
      lowerCaseMessage.includes("quanto tempo") ||
      lowerCaseMessage.includes("quando chega") ||
      lowerCaseMessage.includes("previsão") ||
      lowerCaseMessage.includes("espera") ||
      lowerCaseMessage.includes("demorar") ||
      (lowerCaseMessage.includes("pedido") && lowerCaseMessage.includes("chegar"))
    ) {
      return "Seu pedido está sendo processado! O tempo de entrega é de 40 minutos a 1 hora, dependendo da sua localização. Você pode acompanhar o status do seu pedido pelo nosso site. Estamos trabalhando para que seu açaí chegue o mais rápido possível! 😊"
    }

    // Status do pedido
    if (
      (lowerCaseMessage.includes("status") && lowerCaseMessage.includes("pedido")) ||
      lowerCaseMessage.includes("onde está meu pedido") ||
      lowerCaseMessage.includes("cadê meu pedido") ||
      lowerCaseMessage.includes("acompanhar") ||
      lowerCaseMessage.includes("rastrear")
    ) {
      return "Seu pedido está sendo preparado com todo carinho! Você pode acompanhar o status em tempo real na página de confirmação do pedido. Assim que sair para entrega, você receberá uma notificação por e-mail ou SMS. O tempo estimado é de 40 minutos a 1 hora."
    }

    // Respostas pré-definidas para perguntas comuns sobre carrinho e compras
    if (lowerCaseMessage.includes("carrinho") || lowerCaseMessage.includes("adicionar")) {
      return "Para adicionar itens ao seu carrinho, basta clicar no botão 'Adicionar ao Carrinho' em qualquer produto que desejar. Você pode visualizar seu carrinho a qualquer momento clicando no ícone de carrinho no canto superior direito da tela. Posso ajudar com mais alguma coisa?"
    }

    if (
      lowerCaseMessage.includes("finalizar") ||
      lowerCaseMessage.includes("compra") ||
      lowerCaseMessage.includes("checkout") ||
      lowerCaseMessage.includes("pagar")
    ) {
      return "Para finalizar sua compra, clique no ícone do carrinho no canto superior direito, confira seus itens e clique em 'Finalizar Compra'. Na página de checkout, você informará seus dados de entrega e escolherá a forma de pagamento. Após confirmar, seu pedido será processado e entregue em 40 minutos a 1 hora!"
    }

    if (lowerCaseMessage.includes("entrega") || lowerCaseMessage.includes("prazo")) {
      return "Nosso prazo de entrega é de 40 minutos a 1 hora, dependendo da sua localização. Trabalhamos para que seu açaí chegue sempre fresquinho e no menor tempo possível! Você receberá atualizações sobre o status do seu pedido por e-mail ou SMS."
    }

    if (lowerCaseMessage.includes("pagamento") || lowerCaseMessage.includes("pagar")) {
      return "Aceitamos diversas formas de pagamento para sua comodidade: cartão de crédito, cartão de débito, PIX e dinheiro na entrega. Você pode escolher a opção mais conveniente durante o processo de checkout. Alguma dúvida específica sobre alguma forma de pagamento?"
    }

    if (lowerCaseMessage.includes("cancelar") || lowerCaseMessage.includes("cancelamento")) {
      return "Para cancelar um pedido, entre em contato conosco imediatamente pelo telefone (11) 9999-9999. Pedidos só podem ser cancelados antes do início do preparo, que geralmente ocorre nos primeiros 5-10 minutos após a confirmação. Posso ajudar com mais alguma coisa?"
    }

    if (lowerCaseMessage.includes("horário") || lowerCaseMessage.includes("funcionamento")) {
      return "Estamos abertos todos os dias das 10h às 22h, incluindo feriados! Sempre prontos para adoçar seu dia com o melhor açaí da cidade. Qual sabor você está pensando em experimentar hoje?"
    }

    if (
      lowerCaseMessage.includes("endereço") ||
      lowerCaseMessage.includes("localização") ||
      lowerCaseMessage.includes("onde") ||
      lowerCaseMessage.includes("loja")
    ) {
      return "Temos várias lojas espalhadas pela cidade para estar sempre perto de você! Para encontrar a mais próxima, informe seu CEP ou bairro e posso indicar a unidade mais conveniente. Todas nossas lojas oferecem o mesmo padrão de qualidade e atendimento!"
    }

    if (
      lowerCaseMessage.includes("cardápio") ||
      lowerCaseMessage.includes("menu") ||
      lowerCaseMessage.includes("produtos") ||
      lowerCaseMessage.includes("sabores")
    ) {
      return "Nosso cardápio completo está disponível na página inicial do site. Temos desde o açaí tradicional até versões especiais como o Açaí Proteico e o Açaí Zero. Você também pode montar seu próprio açaí personalizado com os complementos que preferir! Qual tipo de açaí você costuma preferir?"
    }

    if (
      lowerCaseMessage.includes("olá") ||
      lowerCaseMessage.includes("oi") ||
      lowerCaseMessage.includes("bom dia") ||
      lowerCaseMessage.includes("boa tarde") ||
      lowerCaseMessage.includes("boa noite") ||
      lowerCaseMessage.includes("hey")
    ) {
      return "Olá! Que bom ter você por aqui! Sou o assistente virtual do Açaí do Bairro, pronto para ajudar com informações sobre nossos produtos, pedidos, entregas e muito mais. Como posso te ajudar hoje?"
    }

    if (
      lowerCaseMessage.includes("obrigado") ||
      lowerCaseMessage.includes("obrigada") ||
      lowerCaseMessage.includes("valeu") ||
      lowerCaseMessage.includes("agradeço")
    ) {
      return "Por nada! Estou sempre à disposição para ajudar. Se surgir qualquer outra dúvida, é só me chamar. Desejo um ótimo dia e espero que você aproveite muito seu açaí! 😊"
    }

    if (
      lowerCaseMessage.includes("promoção") ||
      lowerCaseMessage.includes("desconto") ||
      lowerCaseMessage.includes("cupom") ||
      lowerCaseMessage.includes("oferta")
    ) {
      return "Temos sempre promoções especiais acontecendo! Atualmente, temos a promoção 'Compre 1 Leve 2' às terças-feiras e desconto de 15% na primeira compra pelo aplicativo. Acompanhe nossas redes sociais para ficar por dentro de todas as ofertas!"
    }

    if (
      lowerCaseMessage.includes("ingrediente") ||
      lowerCaseMessage.includes("alergia") ||
      lowerCaseMessage.includes("alérgico") ||
      lowerCaseMessage.includes("intolerância") ||
      lowerCaseMessage.includes("glúten") ||
      lowerCaseMessage.includes("lactose")
    ) {
      return "Todos os ingredientes de nossos produtos estão listados em nosso cardápio. Temos opções sem glúten e sem lactose! Se você tem alguma alergia ou restrição alimentar específica, por favor, informe no momento do pedido para que possamos atendê-lo adequadamente."
    }

    return null
  }

  const handleSendMessage = async () => {
    if (!input.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      content: input,
      role: "user",
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsLoading(true)

    try {
      // Verificar se temos uma resposta pré-definida
      const preDefinedResponse = getPreDefinedResponse(input)

      if (preDefinedResponse) {
        // Usar resposta pré-definida com um pequeno atraso para simular processamento
        setTimeout(() => {
          const assistantMessage: Message = {
            id: Date.now().toString(),
            content: preDefinedResponse,
            role: "assistant",
            timestamp: new Date(),
          }
          setMessages((prev) => [...prev, assistantMessage])
          setIsLoading(false)
        }, 800) // Aumentei um pouco o delay para parecer mais natural
      } else {
        // Usar AI SDK para gerar uma resposta contextual
        const { text } = await generateText({
          model: openai("gpt-3.5-turbo"),
          prompt: `Você é um assistente virtual amigável e conversacional de uma loja de açaí chamada "Açaí do Bairro". 
                Responda de forma natural e amigável à seguinte pergunta do cliente: "${input}".
                
                Informações importantes:
                - O tempo de entrega é de 40 minutos a 1 hora
                - Quando perguntarem sobre status de pedidos, informe que o pedido está sendo processado
                - Use um tom conversacional e amigável, como se estivesse conversando com um amigo
                - Inclua emojis ocasionalmente para tornar a conversa mais amigável
                - Mantenha as respostas concisas, com no máximo 3-4 frases
                - Se a pergunta for sobre tempo de entrega, SEMPRE mencione que o tempo é de 40 minutos a 1 hora
                - Se não souber a resposta, sugira que o cliente entre em contato pelo telefone (11) 9999-9999
                
                Responda como se fosse um atendente real, não mencione que é uma IA.`,
          temperature: 0.7,
          maxTokens: 150,
        })

        const assistantMessage: Message = {
          id: Date.now().toString(),
          content: text,
          role: "assistant",
          timestamp: new Date(),
        }

        setMessages((prev) => [...prev, assistantMessage])
      }
    } catch (error) {
      console.error("Erro ao gerar resposta:", error)

      // Mensagem de fallback em caso de erro
      const errorMessage: Message = {
        id: Date.now().toString(),
        content:
          "Desculpe, estou com dificuldades para processar sua pergunta. Por favor, tente novamente ou entre em contato pelo telefone (11) 9999-9999 para falar com um de nossos atendentes.",
        role: "assistant",
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, errorMessage])
    } finally {
      setIsLoading(false)
    }
  }

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
  }

  return (
    <div className="fixed bottom-4 right-4 z-50">
      {/* Botão do chat */}
      <button
        onClick={toggleChat}
        className="bg-amber-500 hover:bg-amber-600 text-black rounded-full p-3 shadow-lg flex items-center justify-center"
        aria-label="Chat com assistente virtual"
      >
        <MessageSquare className="h-6 w-6" />
      </button>

      {/* Janela do chat */}
      {isOpen && (
        <div className="absolute bottom-16 right-0 w-80 sm:w-96 bg-white rounded-lg shadow-xl overflow-hidden flex flex-col border border-gray-200">
          {/* Cabeçalho do chat */}
          <div className="bg-purple-700 text-white p-3 flex items-center justify-between">
            <div className="flex items-center">
              <MessageSquare className="h-5 w-5 mr-2" />
              <h3 className="font-medium">Assistente Virtual</h3>
            </div>
            <div className="flex items-center">
              <button onClick={toggleMinimize} className="p-1 hover:bg-purple-600 rounded mr-1">
                {isMinimized ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
              </button>
              <button onClick={toggleChat} className="p-1 hover:bg-purple-600 rounded">
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>

          {/* Corpo do chat */}
          {!isMinimized && (
            <>
              <div className="flex-1 p-3 overflow-y-auto max-h-80 bg-gray-50">
                <div className="space-y-3">
                  {messages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
                    >
                      <div
                        className={`max-w-[80%] rounded-lg p-3 ${
                          message.role === "user" ? "bg-amber-500 text-black" : "bg-gray-200 text-gray-800"
                        }`}
                      >
                        <p className="text-sm">{message.content}</p>
                        <p className="text-xs mt-1 opacity-70 text-right">{formatTime(message.timestamp)}</p>
                      </div>
                    </div>
                  ))}
                  {isLoading && (
                    <div className="flex justify-start">
                      <div className="max-w-[80%] rounded-lg p-3 bg-gray-200 text-gray-800">
                        <div className="flex space-x-1">
                          <div className="w-2 h-2 rounded-full bg-gray-400 animate-bounce"></div>
                          <div className="w-2 h-2 rounded-full bg-gray-400 animate-bounce delay-100"></div>
                          <div className="w-2 h-2 rounded-full bg-gray-400 animate-bounce delay-200"></div>
                        </div>
                      </div>
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </div>
              </div>

              {/* Input do chat */}
              <div className="p-3 border-t">
                <div className="flex items-center">
                  <input
                    ref={inputRef}
                    type="text"
                    value={input}
                    onChange={handleInputChange}
                    onKeyDown={handleKeyDown}
                    placeholder="Digite sua mensagem..."
                    className="flex-1 p-2 border rounded-l-md focus:outline-none focus:ring-2 focus:ring-purple-500"
                    disabled={isLoading}
                  />
                  <button
                    onClick={handleSendMessage}
                    disabled={!input.trim() || isLoading}
                    className={`p-2 rounded-r-md ${
                      !input.trim() || isLoading
                        ? "bg-gray-300 text-gray-500"
                        : "bg-amber-500 hover:bg-amber-600 text-black"
                    }`}
                  >
                    <Send className="h-5 w-5" />
                  </button>
                </div>
                <p className="text-xs text-gray-500 mt-2 text-center">Assistente virtual do Açaí do Bairro</p>
              </div>
            </>
          )}
        </div>
      )}
    </div>
  )
}
