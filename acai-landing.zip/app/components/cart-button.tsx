"use client"

import { useState } from "react"
import { ShoppingCart, X } from "lucide-react"
import { useCart } from "../context/cart-context"
import { useRouter } from "next/navigation"

export default function CartButton() {
  const router = useRouter()
  const { items, itemCount, total, removeItem } = useCart()
  const [isOpen, setIsOpen] = useState(false)

  const toggleCart = () => {
    setIsOpen(!isOpen)
  }

  const formatPrice = (price: number) => {
    return price.toFixed(2).replace(".", ",")
  }

  const handleCheckout = () => {
    setIsOpen(false)
    router.push("/checkout")
  }

  return (
    <div className="relative">
      <button className="relative p-2 hover:text-amber-400 transition-colors" onClick={toggleCart}>
        <ShoppingCart className="h-6 w-6" />
        {itemCount > 0 && (
          <span className="absolute -top-1 -right-1 bg-amber-500 text-black text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
            {itemCount}
          </span>
        )}
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-80 bg-white rounded-md shadow-lg z-50 overflow-hidden">
          <div className="p-4 border-b">
            <div className="flex justify-between items-center">
              <h3 className="font-bold text-gray-900">Seu Carrinho</h3>
              <button onClick={toggleCart} className="text-gray-500 hover:text-gray-700">
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>

          <div className="max-h-96 overflow-y-auto">
            {items.length === 0 ? (
              <div className="p-4 text-center text-gray-500">Seu carrinho está vazio</div>
            ) : (
              <div>
                {items.map((item, index) => (
                  <div key={`${item.id}-${item.size}-${index}`} className="p-4 border-b flex items-center gap-3">
                    <div className="w-12 h-12 bg-gray-100 rounded-md overflow-hidden flex-shrink-0">
                      <img
                        src={item.image || "/placeholder.svg"}
                        alt={item.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium text-sm">{item.name}</h4>
                      <p className="text-xs text-gray-500">Tamanho: {item.size}</p>
                      <div className="flex justify-between items-center mt-1">
                        <span className="text-sm font-medium">
                          {item.quantity} x R$ {formatPrice(item.price)}
                        </span>
                        <button
                          onClick={() => removeItem(item.id, item.size)}
                          className="text-red-500 hover:text-red-700 text-xs"
                        >
                          Remover
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="p-4 border-t">
            <div className="flex justify-between items-center mb-4">
              <span className="font-medium">Total:</span>
              <span className="font-bold">R$ {formatPrice(total)}</span>
            </div>
            <button
              className="w-full bg-amber-500 hover:bg-amber-600 text-black font-medium py-2 rounded-md transition-colors"
              disabled={items.length === 0}
              onClick={handleCheckout}
            >
              Finalizar Compra
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
