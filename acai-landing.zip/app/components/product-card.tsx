"use client"

import { useState } from "react"
import Image from "next/image"
import { useCart } from "../context/cart-context"

type ProductProps = {
  id: string
  name: string
  price: number
  description: string
  image: string
}

export default function ProductCard({ id, name, price, description, image }: ProductProps) {
  const [selectedSize, setSelectedSize] = useState("300ml")
  const { addItem } = useCart()

  const handleAddToCart = () => {
    addItem({
      id,
      name,
      price: price + getSizePrice(selectedSize),
      size: selectedSize,
      image,
    })
  }

  const getSizePrice = (size: string) => {
    switch (size) {
      case "300ml":
        return 0
      case "500ml":
        return 4
      case "700ml":
        return 8
      default:
        return 0
    }
  }

  const formatPrice = (price: number) => {
    return price.toFixed(2).replace(".", ",")
  }

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden border border-gray-200 transition-transform hover:scale-105 flex flex-col">
      <div className="relative pt-[100%] bg-gray-50">
        <Image
          src={image || "/placeholder.svg"}
          alt={name}
          fill
          className="object-cover"
          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
        />
      </div>
      <div className="p-6 flex-1 flex flex-col">
        <h3 className="text-xl font-bold mb-2">{name}</h3>
        <div className="text-amber-500 font-bold text-xl mb-2">
          R$ {formatPrice(price + getSizePrice(selectedSize))}
        </div>
        <p className="text-gray-700 mb-4 flex-1">{description}</p>
        <div className="flex flex-col gap-2 mt-auto">
          <div className="flex items-center justify-between text-sm text-gray-600 mb-4">
            <span>Tamanho:</span>
            <div className="flex gap-2">
              <button
                className={`px-2 py-1 border rounded ${selectedSize === "300ml" ? "bg-amber-100 border-amber-500" : "border-gray-300 hover:bg-gray-100"}`}
                onClick={() => setSelectedSize("300ml")}
              >
                300ml
              </button>
              <button
                className={`px-2 py-1 border rounded ${selectedSize === "500ml" ? "bg-amber-100 border-amber-500" : "border-gray-300 hover:bg-gray-100"}`}
                onClick={() => setSelectedSize("500ml")}
              >
                500ml
              </button>
              <button
                className={`px-2 py-1 border rounded ${selectedSize === "700ml" ? "bg-amber-100 border-amber-500" : "border-gray-300 hover:bg-gray-100"}`}
                onClick={() => setSelectedSize("700ml")}
              >
                700ml
              </button>
            </div>
          </div>
          <button
            className="w-full bg-amber-500 hover:bg-amber-600 text-black font-medium py-2 rounded-md transition-colors"
            onClick={handleAddToCart}
          >
            Adicionar ao Carrinho
          </button>
        </div>
      </div>
    </div>
  )
}
