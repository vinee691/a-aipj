"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { useParams, useRouter } from "next/navigation"
import { ArrowLeft, RefreshCw, LogOut } from "lucide-react"
import { useOrders, type Order } from "../../../context/orders-context"
import { useAuth } from "../../../context/auth-context"

export default function OrderDetailsPage() {
  const router = useRouter()
  const params = useParams()
  const { getOrder, updateOrderStatus } = useOrders()
  const { user, logout } = useAuth()
  const [order, setOrder] = useState<Order | null>(null)

  useEffect(() => {
    if (params.id) {
      const orderId = Array.isArray(params.id) ? params.id[0] : params.id
      const foundOrder = getOrder(orderId)

      if (foundOrder) {
        setOrder(foundOrder)
      } else {
        // Redirecionar para a página de admin se o pedido não for encontrado
        router.push("/admin")
      }
    }
  }, [params.id, getOrder, router])

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return new Intl.DateTimeFormat("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    }).format(date)
  }

  const formatPrice = (price: number) => {
    return price.toFixed(2).replace(".", ",")
  }

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "pending":
        return <span className="px-2 py-1 bg-yellow-100 text-yellow-800 rounded-full text-xs">Pendente</span>
      case "completed":
        return <span className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs">Concluído</span>
      case "cancelled":
        return <span className="px-2 py-1 bg-red-100 text-red-800 rounded-full text-xs">Cancelado</span>
      case "refunded":
        return <span className="px-2 py-1 bg-purple-100 text-purple-800 rounded-full text-xs">Estornado</span>
      default:
        return <span className="px-2 py-1 bg-gray-100 text-gray-800 rounded-full text-xs">Desconhecido</span>
    }
  }

  const getPaymentMethodLabel = (method: string) => {
    switch (method) {
      case "credit":
        return "Cartão de Crédito"
      case "debit":
        return "Cartão de Débito"
      case "pix":
        return "PIX"
      case "cash":
        return "Dinheiro"
      default:
        return method
    }
  }

  const handleRefund = () => {
    if (!order) return

    if (window.confirm("Tem certeza que deseja estornar este pedido?")) {
      updateOrderStatus(order.id, "refunded")
      setOrder({ ...order, status: "refunded" })
    }
  }

  if (!order) {
    return (
      <div className="min-h-screen bg-gray-50 py-12">
        <div className="container mx-auto px-4">
          <div className="bg-white rounded-lg shadow-lg p-8 text-center">
            <p className="text-gray-600 mb-6">Carregando detalhes do pedido...</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between mb-8">
          <Link href="/admin" className="text-gray-600 hover:text-gray-900 flex items-center">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Voltar para a lista de pedidos
          </Link>
          <div className="flex items-center gap-4">
            {user && (
              <div className="text-sm text-gray-600">
                Olá, <span className="font-medium">{user.name}</span>
              </div>
            )}
            <button
              onClick={logout}
              className="flex items-center text-gray-600 hover:text-gray-900 bg-gray-100 hover:bg-gray-200 px-3 py-2 rounded-md text-sm"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Sair
            </button>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-lg overflow-hidden mb-8">
          <div className="p-6 border-b flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold">Pedido #{order.id}</h1>
              <p className="text-gray-500">Realizado em {formatDate(order.createdAt)}</p>
            </div>
            <div className="flex items-center gap-4">
              <div>{getStatusLabel(order.status)}</div>
              {order.status === "completed" && (
                <button
                  onClick={handleRefund}
                  className="bg-red-100 text-red-800 hover:bg-red-200 px-4 py-2 rounded-md text-sm font-medium flex items-center"
                >
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Estornar Pedido
                </button>
              )}
            </div>
          </div>

          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
              <div>
                <h2 className="text-lg font-medium mb-4">Informações do Cliente</h2>
                <div className="bg-gray-50 p-4 rounded-md">
                  <p className="font-medium">{order.customerInfo.name}</p>
                  <p>Email: {order.customerInfo.email}</p>
                  <p>Telefone: {order.customerInfo.phone}</p>
                </div>
              </div>

              <div>
                <h2 className="text-lg font-medium mb-4">Informações de Entrega</h2>
                <div className="bg-gray-50 p-4 rounded-md">
                  <p>
                    {order.customerInfo.address}, {order.customerInfo.number}
                    {order.customerInfo.complement ? ` - ${order.customerInfo.complement}` : ""}
                  </p>
                  <p>
                    {order.customerInfo.neighborhood}, {order.customerInfo.city} - {order.customerInfo.state}
                  </p>
                  <p>CEP: {order.customerInfo.zipcode}</p>
                </div>
              </div>
            </div>

            <div className="mb-8">
              <h2 className="text-lg font-medium mb-4">Método de Pagamento</h2>
              <div className="bg-gray-50 p-4 rounded-md">
                <p>{getPaymentMethodLabel(order.paymentMethod)}</p>
              </div>
            </div>

            <div className="mb-8">
              <h2 className="text-lg font-medium mb-4">Itens do Pedido</h2>
              <div className="border rounded-md overflow-hidden">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th
                        scope="col"
                        className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                      >
                        Produto
                      </th>
                      <th
                        scope="col"
                        className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                      >
                        Tamanho
                      </th>
                      <th
                        scope="col"
                        className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                      >
                        Quantidade
                      </th>
                      <th
                        scope="col"
                        className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                      >
                        Preço Unitário
                      </th>
                      <th
                        scope="col"
                        className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                      >
                        Subtotal
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {order.items.map((item, index) => (
                      <tr key={`${item.id}-${item.size}-${index}`}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="h-10 w-10 flex-shrink-0 mr-3">
                              <img
                                className="h-10 w-10 rounded-full object-cover"
                                src={item.image || "/placeholder.svg"}
                                alt={item.name}
                              />
                            </div>
                            <div className="text-sm font-medium text-gray-900">{item.name}</div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.size}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.quantity}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          R$ {formatPrice(item.price)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          R$ {formatPrice(item.price * item.quantity)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="flex justify-end">
              <div className="w-full md:w-1/3">
                <div className="border-t pt-4 space-y-2">
                  <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span>R$ {formatPrice(order.total - 5)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Taxa de entrega</span>
                    <span>R$ 5,00</span>
                  </div>
                  <div className="flex justify-between font-bold text-lg border-t border-dashed pt-4 mt-4">
                    <span>Total</span>
                    <span>R$ {formatPrice(order.total)}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
